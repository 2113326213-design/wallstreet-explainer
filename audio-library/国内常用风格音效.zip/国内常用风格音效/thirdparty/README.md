# Kenney 音效：界面与提示

150 条独立声音文件（从原 OGG 转为 WAV）：来自 Kenney 的 Interface Sounds（100）与 UI Audio（50）音效包，作者 Kenney。适合短视频常见的点击、选择、疑问、错误、开关和故障效果。它们是不同版本的声音，不是 150 种不同大类，也不是国内热门原版或按使用量排行。

- 授权：两个音效包均为 CC0，可以商业使用和再分发；保留了原始许可文件。
- 原作者页面：https://kenney.nl/assets/interface-sounds 和 https://kenney.nl/assets/ui-audio
- 原 OGG 下载镜像：https://github.com/GeorgeQLe/assets-sfx-ui ，固定版本 `760afd035e8fc3cd7fb5bc58d49a967649875e3e`，索引提供单文件地址。原站的官方包下载在当前环境返回 403；本次原始文件来自前述第三方镜像，原作者官网确认对应包为 CC0。
- 所有文件均已逐条解码成功并核对非空，150 条解码音频内容无重复；也与现有 Wyzowl 320 条音效按 PCM 对比无相同文件。时长较短的点击、故障及滴答是原音效的自然时长。
- `index.json` 和 `index.csv` 每条记录名称、分类、时长、路径、作者、来源、许可、原始文件地址与 SHA-256。

为避免 OGG 解码转换到 16 位整数时发生削波，15 个较响原音效在转为 WAV 时降低了 2 或 4 dB；具体文件以 `index.json` / `index.csv` 的 note 为准。各文件的时长、SHA-256 均已更新。
