window.BACKGROUNDS=[
  {
    "file": "part-01/01-navy.jpg",
    "title": "光晕 · navy",
    "category": "原创抽象",
    "design": "光晕",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/01-jade.jpg",
    "title": "光晕 · jade",
    "category": "原创抽象",
    "design": "光晕",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/01-wine.jpg",
    "title": "光晕 · wine",
    "category": "原创抽象",
    "design": "光晕",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/01-sand.jpg",
    "title": "光晕 · sand",
    "category": "原创抽象",
    "design": "光晕",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/02-navy.jpg",
    "title": "同心弧线 · navy",
    "category": "原创抽象",
    "design": "同心弧线",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/02-jade.jpg",
    "title": "同心弧线 · jade",
    "category": "原创抽象",
    "design": "同心弧线",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/02-wine.jpg",
    "title": "同心弧线 · wine",
    "category": "原创抽象",
    "design": "同心弧线",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/02-sand.jpg",
    "title": "同心弧线 · sand",
    "category": "原创抽象",
    "design": "同心弧线",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/03-navy.jpg",
    "title": "几何斜切 · navy",
    "category": "原创抽象",
    "design": "几何斜切",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/03-jade.jpg",
    "title": "几何斜切 · jade",
    "category": "原创抽象",
    "design": "几何斜切",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/03-wine.jpg",
    "title": "几何斜切 · wine",
    "category": "原创抽象",
    "design": "几何斜切",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/03-sand.jpg",
    "title": "几何斜切 · sand",
    "category": "原创抽象",
    "design": "几何斜切",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/04-navy.jpg",
    "title": "网格 · navy",
    "category": "原创抽象",
    "design": "网格",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/04-jade.jpg",
    "title": "网格 · jade",
    "category": "原创抽象",
    "design": "网格",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/04-wine.jpg",
    "title": "网格 · wine",
    "category": "原创抽象",
    "design": "网格",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/04-sand.jpg",
    "title": "网格 · sand",
    "category": "原创抽象",
    "design": "网格",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/05-navy.jpg",
    "title": "点阵 · navy",
    "category": "原创抽象",
    "design": "点阵",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/05-jade.jpg",
    "title": "点阵 · jade",
    "category": "原创抽象",
    "design": "点阵",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/05-wine.jpg",
    "title": "点阵 · wine",
    "category": "原创抽象",
    "design": "点阵",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/05-sand.jpg",
    "title": "点阵 · sand",
    "category": "原创抽象",
    "design": "点阵",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/06-navy.jpg",
    "title": "流动曲线 · navy",
    "category": "原创抽象",
    "design": "流动曲线",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/06-jade.jpg",
    "title": "流动曲线 · jade",
    "category": "原创抽象",
    "design": "流动曲线",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/06-wine.jpg",
    "title": "流动曲线 · wine",
    "category": "原创抽象",
    "design": "流动曲线",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/06-sand.jpg",
    "title": "流动曲线 · sand",
    "category": "原创抽象",
    "design": "流动曲线",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/07-navy.jpg",
    "title": "数据柱线 · navy",
    "category": "原创抽象",
    "design": "数据柱线",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/07-jade.jpg",
    "title": "数据柱线 · jade",
    "category": "原创抽象",
    "design": "数据柱线",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/07-wine.jpg",
    "title": "数据柱线 · wine",
    "category": "原创抽象",
    "design": "数据柱线",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/07-sand.jpg",
    "title": "数据柱线 · sand",
    "category": "原创抽象",
    "design": "数据柱线",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/08-navy.jpg",
    "title": "线框 · navy",
    "category": "原创抽象",
    "design": "线框",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/08-jade.jpg",
    "title": "线框 · jade",
    "category": "原创抽象",
    "design": "线框",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/08-wine.jpg",
    "title": "线框 · wine",
    "category": "原创抽象",
    "design": "线框",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/08-sand.jpg",
    "title": "线框 · sand",
    "category": "原创抽象",
    "design": "线框",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/09-navy.jpg",
    "title": "弧形边界 · navy",
    "category": "原创抽象",
    "design": "弧形边界",
    "palette": "navy",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/09-jade.jpg",
    "title": "弧形边界 · jade",
    "category": "原创抽象",
    "design": "弧形边界",
    "palette": "jade",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/09-wine.jpg",
    "title": "弧形边界 · wine",
    "category": "原创抽象",
    "design": "弧形边界",
    "palette": "wine",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "file": "part-01/09-sand.jpg",
    "title": "弧形边界 · sand",
    "category": "原创抽象",
    "design": "弧形边界",
    "palette": "sand",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "本项目原创",
    "creator": "本项目"
  },
  {
    "title": "Adams Mountain, Yellow Buck Mountain, Brown Mountain from Beacon Heights, NC, Oct 2016.jpg",
    "category": "山川风景",
    "file": "part-01/52187964.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Adams_Mountain,_Yellow_Buck_Mountain,_Brown_Mountain_from_Beacon_Heights,_NC,_Oct_2016.jpg",
    "author": "Thomson200",
    "sha256": "f0cf9fc066c6d1bf6e23b5bc4d40f35e792694d7f5d850dbb93703cd9fc4437e",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Fatigue Mountain.jpg",
    "category": "山川风景",
    "file": "part-01/129583352.jpg",
    "width": 1920,
    "height": 861,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Fatigue_Mountain.jpg",
    "author": "Rschroeder1985",
    "sha256": "1fd6c62377be2ebbcb2c6d170171e3f36c8969949429a6469069fe8dd11e721f",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Lake Mountain Landscape.jpg",
    "category": "山川风景",
    "file": "part-01/117648128.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Lake_Mountain_Landscape.jpg",
    "author": "Bonnie Moreland",
    "sha256": "5849c2e8c2f1ceb74841cd61b53e1ffbf3c4ef60a561dbc33c2f65f34174850a",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Mountain lake dam.jpg",
    "category": "山川风景",
    "file": "part-01/82512662.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Mountain_lake_dam.jpg",
    "author": "Paul Gilmore",
    "sha256": "020ceb32fc7e083f3e9de88d278a3d85fea12f332e96dd8d022e1c0de77c0725",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Photogenic mountain along the Ponteilles slope, La Thuile, 2024.jpg",
    "category": "山川风景",
    "file": "part-01/147944145.jpg",
    "width": 1920,
    "height": 1277,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Photogenic_mountain_along_the_Ponteilles_slope,_La_Thuile,_2024.jpg",
    "author": "DimiTalen",
    "sha256": "7ed1468a41fe2c938d307dbb1f0eb84b39807f44f6ab178e23d65b8eb5ceb8e7",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Pine Log Mountain and Bear Mountain, Cherokee County, Georgia.jpg",
    "category": "山川风景",
    "file": "part-01/42756133.jpg",
    "width": 1920,
    "height": 1110,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Pine_Log_Mountain_and_Bear_Mountain,_Cherokee_County,_Georgia.jpg",
    "author": "Thomson200",
    "sha256": "838dbbb02e53bafb32cf8b9d963a4c596f5b35c0a69aa14888c6ff9a40c54303",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Rio de Janeiro skyline and Sugarloaf Mountain at sunset, Brazil 3.jpg",
    "category": "日落风景",
    "file": "part-01/134699719.jpg",
    "width": 1920,
    "height": 1174,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Rio_de_Janeiro_skyline_and_Sugarloaf_Mountain_at_sunset,_Brazil_3.jpg",
    "author": "Wilfredor",
    "sha256": "eac6e3b8f3065a1f0fca48e29f2e0b01eb9320a4d81ed6e04ceb21296100efa6",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Rio skyline and Cristo Redentor from Sugarloaf Mountain, Brazil.jpg",
    "category": "山川风景",
    "file": "part-01/135532797.jpg",
    "width": 1920,
    "height": 1157,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Rio_skyline_and_Cristo_Redentor_from_Sugarloaf_Mountain,_Brazil.jpg",
    "author": "Wilfredor",
    "sha256": "852bf4bf990acc215e2f5cb5c510e06b91e18b6f4a2d3f4da7fbab2fecb0910a",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "San Jacinto Mountains and Cahuilla Mountain, as seen from Oak Mountain Pano.jpg",
    "category": "山川风景",
    "file": "part-01/158420116.jpg",
    "width": 1920,
    "height": 844,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:San_Jacinto_Mountains_and_Cahuilla_Mountain,_as_seen_from_Oak_Mountain_Pano.jpg",
    "author": "Z3lvs",
    "sha256": "67ec222d001f5221a3860066ff6e7ff052397af8fcde340d609102d0910e2e0f",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Springer Mountain and Black Mountain, Georgia.JPG",
    "category": "山川风景",
    "file": "part-01/41703034.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Springer_Mountain_and_Black_Mountain,_Georgia.JPG",
    "author": "Thomson200",
    "sha256": "5c0bd8b3f82b02be5e20dd67f7e2a4559e281ad36a80a12bb65ffa8d9108d4e2",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Vallecito Mountain NM.jpg",
    "category": "山川风景",
    "file": "part-01/132585655.jpg",
    "width": 1920,
    "height": 1081,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Vallecito_Mountain_NM.jpg",
    "author": "Thomson200",
    "sha256": "0a95bb56669a8a3a1a4afd3b8a51934414977649b01d3cd2bd7511107a395f91",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Aegina sunset.jpg",
    "category": "日落风景",
    "file": "part-01/49540795.jpg",
    "width": 1920,
    "height": 1233,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Aegina_sunset.jpg",
    "author": "Jebulon",
    "sha256": "a99dd74d5cfb5e1b2089918cf46a9dbb306813fd0ec003dab80dbfc1571af28c",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Backlit Margarita Island Sunset in Las Guevaras, Venezuela CaptureNX2.jpg",
    "category": "日落风景",
    "file": "part-01/32176387.jpg",
    "width": 1920,
    "height": 1293,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Backlit_Margarita_Island_Sunset_in_Las_Guevaras,_Venezuela_CaptureNX2.jpg",
    "author": "Wilfredor",
    "sha256": "be04e95883a8da349faa39653be4654164af4256e7098d061ab13d9b2e6c0303",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Cathedral of Urbino and Surrounding Buildings at Sunset, June 2026.jpg",
    "category": "日落风景",
    "file": "part-01/199494913.jpg",
    "width": 1920,
    "height": 1289,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Cathedral_of_Urbino_and_Surrounding_Buildings_at_Sunset,_June_2026.jpg",
    "author": "Julian Lupyan",
    "sha256": "95274ea14accf9c14072a1c88deb475213d6d315aa33447b826ec948893ca92d",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Grand Canyon South Rim at Sunset.jpg",
    "category": "日落风景",
    "file": "part-01/138088856.jpg",
    "width": 1920,
    "height": 613,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Grand_Canyon_South_Rim_at_Sunset.jpg",
    "author": "Mgimelfarb",
    "sha256": "f870c6b89345cf2850374e541b5b17fd321aa4d86004df276b860fac05d0e512",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Juan Griego Sunset.jpg",
    "category": "日落风景",
    "file": "part-01/32359208.jpg",
    "width": 1920,
    "height": 1094,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Juan_Griego_Sunset.jpg",
    "author": "Wilfredor",
    "sha256": "ce59259d325cc810c52dc90d121dc059add207512b1f46ac3de26d29595d8981",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset Glow.jpg",
    "category": "日落风景",
    "file": "part-01/177712858.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_Glow.jpg",
    "author": "Shivanianbukumar",
    "sha256": "cbbdf0f790fadefb83d0a1a8485b59d4b80d2e8de5e8e398037a3661d654cc8c",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset Hôtel Le Concorde.jpg",
    "category": "日落风景",
    "file": "part-01/95376143.jpg",
    "width": 1920,
    "height": 1159,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_H%C3%B4tel_Le_Concorde.jpg",
    "author": "Wilfredor",
    "sha256": "cbf772408def0565678febfb81964bc410c741e22943a4ff5ea0656e48b25d61",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset Key and Sailboats, Florida, 2025.jpg",
    "category": "日落风景",
    "file": "part-01/179278744.jpg",
    "width": 1920,
    "height": 1000,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_Key_and_Sailboats,_Florida,_2025.jpg",
    "author": "Julian Lupyan",
    "sha256": "9beaa512a713ba37778f25d91dfb01e7c3b2a9041ac561641492a738685780d7",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset Rupel.jpg",
    "category": "日落风景",
    "file": "part-01/197434275.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_Rupel.jpg",
    "author": "JurgenVdP",
    "sha256": "8a5abfa7db7f1ced5bd61eab132d120403a895ddf856b485553621a18051a4b5",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset at Rovinj.jpg",
    "category": "日落风景",
    "file": "part-01/143504646.jpg",
    "width": 1920,
    "height": 886,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_at_Rovinj.jpg",
    "author": "Gvjekoslav",
    "sha256": "dd7f0a7ed204760b67617d89be948bb56464608766e705e924f61b393f3ee7c7",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset from Dresser Hill, Charlton MA 2026-05-10.jpg",
    "category": "日落风景",
    "file": "part-01/191769155.jpg",
    "width": 1920,
    "height": 1152,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_from_Dresser_Hill,_Charlton_MA_2026-05-10.jpg",
    "author": "Peter Cooper Jr.",
    "sha256": "bf289e0f36ddaefcf6a8384d01478e9934cf84af9ff05941f63d30ae6772d83d",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset kigal.jpg",
    "category": "日落风景",
    "file": "part-01/188314012.jpg",
    "width": 1920,
    "height": 1364,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_kigal.jpg",
    "author": "Tuyishimejosue",
    "sha256": "6efeaeea82b8ef5d3482ab76f7eafdc8870d28ec50f0382a02163fe077db0d57",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset over Brofjorden at Loddebo 1.jpg",
    "category": "日落风景",
    "file": "part-01/88684364.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_over_Brofjorden_at_Loddebo_1.jpg",
    "author": "W.carter",
    "sha256": "eb5913ec8c952540a8be51249125d4e524ceb47b3bc6c3397ea9b15007d76e31",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sunset over Quebec City.jpg",
    "category": "城市景色",
    "file": "part-01/143175065.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sunset_over_Quebec_City.jpg",
    "author": "Wilfredor",
    "sha256": "c5ef6f7734675dc6f4b9653fb7103245e76f11c1a3db44065c157981d887c84b",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Beach, Marker Wadden, 2022.jpg",
    "category": "海岸风景",
    "file": "part-01/135652527.jpg",
    "width": 1920,
    "height": 1277,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Beach,_Marker_Wadden,_2022.jpg",
    "author": "DimiTalen",
    "sha256": "8b6af41c958875192d14372d13a3b01d198f6418a5436037ce004551a91225a4",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Beach huts at Stångehuvud 1.jpg",
    "category": "海岸风景",
    "file": "part-01/61302526.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Beach_huts_at_St%C3%A5ngehuvud_1.jpg",
    "author": "W.carter",
    "sha256": "3ca6c447df004f1323e162bdee51a71b619974bc5c6155a1cd9346d4e1717f52",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Beach in Kurskoe, Kirghizistan 01.jpg",
    "category": "海岸风景",
    "file": "part-01/143070393.jpg",
    "width": 1920,
    "height": 1132,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Beach_in_Kurskoe,_Kirghizistan_01.jpg",
    "author": "Bgag",
    "sha256": "b712299a70393c98caf78f3c3dd4025559dfd48900e8707ab937ee20bcf41d09",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Boughrara Beach.jpg",
    "category": "海岸风景",
    "file": "part-01/148806835.jpg",
    "width": 1920,
    "height": 1203,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Boughrara_Beach.jpg",
    "author": "Smailtn",
    "sha256": "e07209fa8014ab79c67cab4bb3f7e8da1f18a2df6f81ca3ae26bce34b12da67c",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Boulders Beach, South Africa.jpg",
    "category": "海岸风景",
    "file": "part-01/77722797.jpg",
    "width": 1920,
    "height": 969,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Boulders_Beach,_South_Africa.jpg",
    "author": "jeffgreenca",
    "sha256": "b298091ea5cb16e1d440d87119380da305ca5a0e048c1d07d9946c7833ffccf4",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Nallikari Beach Oulu 20140427.jpg",
    "category": "海岸风景",
    "file": "part-02/176120901.jpg",
    "width": 1920,
    "height": 1200,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Nallikari_Beach_Oulu_20140427.jpg",
    "author": "Estormiz",
    "sha256": "6d30e112c26614a728ac13ee774bf979cfb00950a87c3fc74036b7cd24de38b9",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Om beach Gokarna.JPG",
    "category": "海岸风景",
    "file": "part-02/15054075.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Om_beach_Gokarna.JPG",
    "author": "Axis of eran",
    "sha256": "add373fbb21974db73724e16a6f4edfdaf75b603086f0bd400f592217ee5922d",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Parasols, Evening, Beach, Rincon de la Victoria, Andalusia, Spain.jpg",
    "category": "海岸风景",
    "file": "part-02/36289052.jpg",
    "width": 1920,
    "height": 1278,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Parasols,_Evening,_Beach,_Rincon_de_la_Victoria,_Andalusia,_Spain.jpg",
    "author": "Jebulon",
    "sha256": "4de91ba5819d2cfa1481489fcd2ae7eedafce62c55ac9dd283c045e7b23e4416",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Rocks, Touddmine beach, Tafedna, Morocco, 2008.jpg",
    "category": "海岸风景",
    "file": "part-02/143481824.jpg",
    "width": 1920,
    "height": 1277,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Rocks,_Touddmine_beach,_Tafedna,_Morocco,_2008.jpg",
    "author": "DimiTalen",
    "sha256": "2109b570055c04a497a99592cf402b72b8e1cc83850d4297e4c2cbbffd198d3b",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Rossbeigh Beach, view from the beach onto Slieve Mish Mountains.jpg",
    "category": "海岸风景",
    "file": "part-02/177014768.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Rossbeigh_Beach,_view_from_the_beach_onto_Slieve_Mish_Mountains.jpg",
    "author": "Podstawko",
    "sha256": "25398a9de422eb52822b3d2c6ad57037969cc79cab83a2dfb31066ceb142fe11",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Sugandha Beach, Cox's Bazar.jpg",
    "category": "海岸风景",
    "file": "part-02/202166969.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sugandha_Beach,_Cox%27s_Bazar.jpg",
    "author": "Munshimiyan",
    "sha256": "7278fdbb9e9524b659a83b1776c2d545a0042f24ddb3e9e111b62a6894ce5c37",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Tabayat beach, towards the south, Timizguida Ouftas, Morocco, 2008.jpg",
    "category": "海岸风景",
    "file": "part-02/143470210.jpg",
    "width": 1920,
    "height": 985,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Tabayat_beach,_towards_the_south,_Timizguida_Ouftas,_Morocco,_2008.jpg",
    "author": "DimiTalen",
    "sha256": "6a367750141a2a4095151b448e2603675222a7c49d53ac604a0e5170af96549e",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "The Sunny Beach 2.jpg",
    "category": "海岸风景",
    "file": "part-02/114727040.jpg",
    "width": 1920,
    "height": 1300,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:The_Sunny_Beach_2.jpg",
    "author": "Ivano Giambattista",
    "sha256": "2b49a6238de0478cd67b4d37c0cc60688293060aa3f372abc45833b8af94d13f",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Cloudy Sky Background.jpg",
    "category": "天空风景",
    "file": "part-02/117613776.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Cloudy_Sky_Background.jpg",
    "author": "Free Nature Stock",
    "sha256": "3f65b2844cf98cd51f06380899890b2d641c05fc05a42da74154a104a305a3d3",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Lighthouse Sky Landscape.jpg",
    "category": "天空风景",
    "file": "part-02/117738456.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Lighthouse_Sky_Landscape.jpg",
    "author": "Holly's Coastal View",
    "sha256": "6573b72b38b62b087ff79a2d126c5127107bb29ec78750bb0c495083fb0569fe",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Reflection of sky in a ploughed field.jpg",
    "category": "天空风景",
    "file": "part-02/59358467.jpg",
    "width": 1920,
    "height": 1138,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Reflection_of_sky_in_a_ploughed_field.jpg",
    "author": "W.carter",
    "sha256": "517628241b0e3d6798fb529ff272df532985d51efd7ceb218aec01a6614f4644",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "The magical sky 2.jpg",
    "category": "天空风景",
    "file": "part-02/194024206.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:The_magical_sky_2.jpg",
    "author": "Asrir Karim Asif",
    "sha256": "15a462758aae3c1d22ec2fe6b9eb586c2449e9a238217d4ac8a9ba523dfc7daf",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Kyzylkum Desert in Uzbekistan.jpg",
    "category": "沙漠风景",
    "file": "part-02/142979841.jpg",
    "width": 1920,
    "height": 1101,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Kyzylkum_Desert_in_Uzbekistan.jpg",
    "author": "Bgag",
    "sha256": "fad589b26639232800e664da67e3cc70c027ac4481c928039602445256c3fd4a",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Landmannalaugar desert road.jpg",
    "category": "沙漠风景",
    "file": "part-02/179363394.jpg",
    "width": 1920,
    "height": 1080,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Landmannalaugar_desert_road.jpg",
    "author": "Syony",
    "sha256": "a5059aad394ea08230bfaf75ad5a71bf92a4b6e2d99f7f0bbc2bd44a98e015ff",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Autumn in Quebec City (in autumn 02).jpg",
    "category": "城市景色",
    "file": "part-02/154209439.jpg",
    "width": 1920,
    "height": 1107,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Autumn_in_Quebec_City_(in_autumn_02).jpg",
    "author": "Wilfredor",
    "sha256": "a1dc321d9affbd0c59c981e1745ca96144fb4d2eaef766fc2102ae7d439237cf",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Autumnal Retreat in Old Quebec- A Canvas of Fading Reds and Vibrant Oranges.jpg",
    "category": "城市景色",
    "file": "part-02/123933333.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Autumnal_Retreat_in_Old_Quebec-_A_Canvas_of_Fading_Reds_and_Vibrant_Oranges.jpg",
    "author": "Wilfredor",
    "sha256": "ffbae6c46a1d755782a9fdfb4d4b7e40b51735ad2e5b2dcfc37a2c178753484f",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Chateau Frontenac at dusk in Quebec City.jpg",
    "category": "城市景色",
    "file": "part-02/123000622.jpg",
    "width": 1920,
    "height": 1296,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Chateau_Frontenac_at_dusk_in_Quebec_City.jpg",
    "author": "Wilfredor",
    "sha256": "807b353e05ddd3427382de893705a77937c23a6d5d0b22449dd517b56aa99ebb",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Chateau Frontenac illuminated at night in Quebec City.jpg",
    "category": "城市景色",
    "file": "part-02/95206526.jpg",
    "width": 1920,
    "height": 1229,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Chateau_Frontenac_illuminated_at_night_in_Quebec_City.jpg",
    "author": "Wilfredor",
    "sha256": "e4e86e66a3afb08f3304c948058f130af800425b6219813dce94d6edb2028a4f",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Gare fluviale de Québec, Quebec city, Canada.jpg",
    "category": "城市景色",
    "file": "part-02/128639471.jpg",
    "width": 1920,
    "height": 715,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Gare_fluviale_de_Qu%C3%A9bec,_Quebec_city,_Canada.jpg",
    "author": "Wilfredor",
    "sha256": "155bc6cfbdb57a1e9db668d193aa43aed41b8f4b31db691ce798e380ad8bf0de",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Hotel Le Concorde at sunset in Quebec City.jpg",
    "category": "城市景色",
    "file": "part-02/153831466.jpg",
    "width": 1920,
    "height": 1251,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Hotel_Le_Concorde_at_sunset_in_Quebec_City.jpg",
    "author": "Wilfredor",
    "sha256": "b1d82e45dee7fd8148f38986fef659aaf2839bab50c58ff82df19721a302da97",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Levis viewed from Quebec City 2.jpg",
    "category": "城市景色",
    "file": "part-02/94910200.jpg",
    "width": 1920,
    "height": 1123,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Levis_viewed_from_Quebec_City_2.jpg",
    "author": "Wilfredor",
    "sha256": "e4ea5325023086b0d3d0a8dc8b5864eaf326068615463f46b4ac57784d042de2",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Price Building illuminated at night in Quebec City.jpg",
    "category": "城市景色",
    "file": "part-02/95206524.jpg",
    "width": 1920,
    "height": 1248,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Price_Building_illuminated_at_night_in_Quebec_City.jpg",
    "author": "Wilfredor",
    "sha256": "d0e163570c5986d7a44a6abc28a1c750cecfc56bd00756306dd92f8ad525307d",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Quebec City skyline from a park.jpg",
    "category": "城市景色",
    "file": "part-02/95467195.jpg",
    "width": 1920,
    "height": 623,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Quebec_City_skyline_from_a_park.jpg",
    "author": "Wilfredor",
    "sha256": "f198b2e6e067bd9d54010a52aa30fe8aac0f26267d6aa40b0b9b6a19cecf62d0",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Snow-covered Quebec City skyline in fog.jpg",
    "category": "城市景色",
    "file": "part-02/143198012.jpg",
    "width": 1920,
    "height": 1280,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Snow-covered_Quebec_City_skyline_in_fog.jpg",
    "author": "Wilfredor",
    "sha256": "81adf33ee7c1331f7c3a8c05b6f80272c7875da232f5b4f18bdb07923f11a8d7",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Spire of Chalmers-Wesley United Church above Quebec City at sunset.jpg",
    "category": "城市景色",
    "file": "part-02/95217891.jpg",
    "width": 1920,
    "height": 1200,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Spire_of_Chalmers-Wesley_United_Church_above_Quebec_City_at_sunset.jpg",
    "author": "Wilfredor",
    "sha256": "36f52e57a3522ff96b1ce226ad510ffd754e6fba56821aa6b364b20e347870ec",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Széchenyi Chain Bridge in Budapest at night.jpg",
    "category": "城市景色",
    "file": "part-02/26955009.jpg",
    "width": 1920,
    "height": 1073,
    "license": "CC0 1.0",
    "source": "https://commons.wikimedia.org/wiki/File:Sz%C3%A9chenyi_Chain_Bridge_in_Budapest_at_night.jpg",
    "author": "Wilfredor",
    "sha256": "b8f418a255acb8647e3303099c5a020139224c1804d85e644eae9aa76cbeff71",
    "source_format": "Wikimedia Commons 1920px 转存 JPEG"
  },
  {
    "title": "Brown Planks 03",
    "category": "木材纹理",
    "file": "part-03/brown_planks_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brown_planks_03",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "8dfae22286fa9bb0ed62ce7326e8bc14c284e567d38fd64b5a453838080ecf19",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Planks Brown 10",
    "category": "木材纹理",
    "file": "part-03/planks_brown_10.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/planks_brown_10",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "71c125acdfde628c3384150b077fa7fa957c87d1f881d5fc561feb99059c15f9",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Kitchen Wood",
    "category": "木材纹理",
    "file": "part-03/kitchen_wood.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/kitchen_wood",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6d0170f1ab1b9353aab6f0382a7753026e32a5b58f779651cd05a91618dfcdab",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Bark Brown 02",
    "category": "木材纹理",
    "file": "part-03/bark_brown_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/bark_brown_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "920fa0bed0c9d78c1d530e99795113afd532d7db746de440f4a85d7c83ed0f1a",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Oak Veneer 01",
    "category": "木材纹理",
    "file": "part-03/oak_veneer_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/oak_veneer_01",
    "author": {
      "Jenelle van Heerden": "All"
    },
    "sha256": "c14681f72f59f17bff568cae7a837641443b607b899f0c279cd64a5638f877a7",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Laminate Floor 02",
    "category": "木材纹理",
    "file": "part-03/laminate_floor_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/laminate_floor_02",
    "author": {
      "Dario Barresi": "Processing",
      "Charlotte Baglioni": "photography"
    },
    "sha256": "c112a8fb107d8600a2974af2f9fa9b595c491a33a59982e22706e9650990bf8f",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Dark Wood",
    "category": "木材纹理",
    "file": "part-03/dark_wood.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/dark_wood",
    "author": {
      "Dario Barresi": "Baking",
      "Dimitrios Savva": "Photography",
      "Rico Cilliers": "Tiling"
    },
    "sha256": "d68da31655bf47024af893156a6a01a6c95bb60f55d97e2dc9bdd47be320e5b5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Plywood",
    "category": "木材纹理",
    "file": "part-03/plywood.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/plywood",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "800905650fc6cab2fe7c77c41851f8ea89669f1287ad5ce67c48f435654c0af8",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Fine Grained Wood",
    "category": "木材纹理",
    "file": "part-03/fine_grained_wood.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/fine_grained_wood",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "d171f45ef01bc6e239b00dfaa4961bcd27f7d8e93e3962da3bd3d0ce703d802c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Old Planks 02",
    "category": "木材纹理",
    "file": "part-03/old_planks_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/old_planks_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "fda6019406a61ce5eb0ccb1cb92fd8f196eca6421cb2e118791ffa51ea005d45",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brown Planks 05",
    "category": "木材纹理",
    "file": "part-03/brown_planks_05.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brown_planks_05",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "2638ddb4b4ea9c3e7835a81cec9d2b41df30187aed6cf0cddee2e5042a39724a",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Laminate Floor 03",
    "category": "木材纹理",
    "file": "part-03/laminate_floor_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/laminate_floor_03",
    "author": {
      "Dario Barresi": "Processing",
      "Charlotte Baglioni": "Photography"
    },
    "sha256": "ce2813cdc714fc5a2d816c9b79a0b4aece71c8d5bf56db52331cf413d950eae3",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Bark Brown 01",
    "category": "木材纹理",
    "file": "part-03/bark_brown_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/bark_brown_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "4213441aebcb72b9911f5a860e9ce74a61a8f6ce3b9c23d1f204173e7e7f6066",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Laminate Floor",
    "category": "木材纹理",
    "file": "part-03/laminate_floor.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/laminate_floor",
    "author": {
      "Dario Barresi": "Processing",
      "Dimitrios Savva": "Photography"
    },
    "sha256": "c3dcfb3ead57674031fbbe9a351fd9737d200afa72ab04047ed7658f0696ec29",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Bark Willow 02",
    "category": "木材纹理",
    "file": "part-03/bark_willow_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/bark_willow_02",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "95e1380566834aab220bd8ea9a5287f3bfff46910c18017fcb46ebbbe832024f",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Bark Willow",
    "category": "木材纹理",
    "file": "part-03/bark_willow.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/bark_willow",
    "author": {
      "Dario Barresi": "Processing",
      "Dimitrios Savva": "Photography"
    },
    "sha256": "c7de3072c2320934a3d9f5bc6c9cb58819952c0b3bd04f4e71b24cf89dbb6ad6",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Dark Wooden Planks",
    "category": "木材纹理",
    "file": "part-03/dark_wooden_planks.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/dark_wooden_planks",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "e8216baa6b2d701b5523fcb904d45570acf7b96d160ef815e96e2dbfa82bdd9b",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Raw Plank Wall",
    "category": "木材纹理",
    "file": "part-03/raw_plank_wall.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/raw_plank_wall",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "c1cb9c95325897e40c3173ed86ad862feaa394cf6c091952b0b1ca0403ac8b43",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Concrete Floor Worn 001",
    "category": "其他材质纹理",
    "file": "part-03/concrete_floor_worn_001.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/concrete_floor_worn_001",
    "author": {
      "Dimitrios Savva": "Photography",
      "Rico Cilliers": "Processing"
    },
    "sha256": "6e40c0fc908f4d66431836f5abe203f3a4eb064e88824378a91a46a26e2f464c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Herringbone Parquet",
    "category": "木材纹理",
    "file": "part-03/herringbone_parquet.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/herringbone_parquet",
    "author": {
      "Jenelle van Heerden": "Processing",
      "Sergej Majboroda": "Photography"
    },
    "sha256": "d6c66492a6c4cfd4e8ed18c9cdd4e0303f3de4e04613d2adca8bc2b8f2dd2350",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Beige Wall 001",
    "category": "其他材质纹理",
    "file": "part-03/beige_wall_001.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/beige_wall_001",
    "author": {
      "Dimitrios Savva": "Photography",
      "Rico Cilliers": "Processing"
    },
    "sha256": "72104704d0b9bd3713c5f6238971252b63eccf6e61263059c674caa8f3d0fa6d",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Green Rough Planks",
    "category": "木材纹理",
    "file": "part-03/green_rough_planks.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/green_rough_planks",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "c14e48538f5fca3d8e9aaa14900be805c11cc5b5c95cde7e6ff9b409decb8ce4",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Plank Flooring 04",
    "category": "木材纹理",
    "file": "part-03/plank_flooring_04.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/plank_flooring_04",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "260fc03a322552176b59c8e6dfc463594daf1f15ed3fedb2601053d8dbd2162c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Blue Painted Planks",
    "category": "木材纹理",
    "file": "part-03/blue_painted_planks.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/blue_painted_planks",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "31bab926cd4fb1f1df9e863af6bbf49e678a0e3b960cbc543e6a36000aaa6b13",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Moss Wood",
    "category": "木材纹理",
    "file": "part-03/moss_wood.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/moss_wood",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "758a9720d29ca030d505fac0f8fdd90db172882ff149d8ea730c11d57c98924c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Pine Bark",
    "category": "木材纹理",
    "file": "part-03/pine_bark.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/pine_bark",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "89ddfbff0388d30caff902ba600cdf75eb1e651ca71ece6594b5a9b27abb47ab",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Concrete Layers 02",
    "category": "其他材质纹理",
    "file": "part-03/concrete_layers_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/concrete_layers_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "cca314fbb793e3928111912f1d6d4d79edf4420402e56019d70fec0bdc2efca5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Painted Plaster Wall",
    "category": "其他材质纹理",
    "file": "part-03/painted_plaster_wall.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/painted_plaster_wall",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "440310f05af089f2c93353167573403cbc3f805948203237b5d26431eeb9e19c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Concrete Floor 02",
    "category": "其他材质纹理",
    "file": "part-04/concrete_floor_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/concrete_floor_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6db84a6d87dc50508b9d134d6fbd2b7e876b8081a5f43a118a249ca18de73af5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Beach 01",
    "category": "沙土纹理",
    "file": "part-04/aerial_beach_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_beach_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "5b849983d08fda1c6d28b95b55851c2227697598721b25ff2b85e57cf8b04fc4",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Green Metal Rust",
    "category": "金属纹理",
    "file": "part-04/green_metal_rust.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/green_metal_rust",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "4509ab0cb1cf6bf9b9f970450a41f83ebd9bff178006deae568ff34b404856fc",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Metal Plate",
    "category": "金属纹理",
    "file": "part-04/metal_plate.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/metal_plate",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "c6b6739eac2c75ccc898e753d7833df24eafbdb9aa92fb6eabfb92abd1a680a5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Interior Tiles",
    "category": "瓷砖纹理",
    "file": "part-04/interior_tiles.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/interior_tiles",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "f267c4357e629f5ca2ab86f30da4fb0ae8c655a566cec6d81278df8d78dcca4a",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Red Brick 03",
    "category": "砖石纹理",
    "file": "part-04/red_brick_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/red_brick_03",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "9c58254c099b2d211478f50a427fcdde622af24249ff2e94da41fb836f8c857f",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Asphalt 01",
    "category": "柏油纹理",
    "file": "part-04/aerial_asphalt_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_asphalt_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "28bfd71288b364f825e0feb750e487410422d80bf3c31d32da01cae3bf085b58",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Red Brick",
    "category": "砖石纹理",
    "file": "part-04/red_brick.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/red_brick",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6dea3a2b5a3185ff48d299d182c405a9f787129d79677792db6de4afd81c47f6",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Coast Sand Rocks 02",
    "category": "岩石纹理",
    "file": "part-04/coast_sand_rocks_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/coast_sand_rocks_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "78eae8ce6209f79417a15ba863fe828f983c22f7e63a9ee3ef504a0062a05ea9",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Coast Sand 01",
    "category": "沙土纹理",
    "file": "part-04/coast_sand_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/coast_sand_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "58af2e40100f7f405703a86d593af64379f822c4786850def23ecfc921450d54",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Rocks 02",
    "category": "岩石纹理",
    "file": "part-04/aerial_rocks_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_rocks_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "708373b2af7fd07ac8de1500556006aaf904c41a99985a849cacc78874f38eac",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Factory Wall",
    "category": "金属纹理",
    "file": "part-04/factory_wall.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/factory_wall",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6a8d2d4decc7754e56b5c4a3371d98ac5c521ebc732f255ddaa3b1bdd2f1a564",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Checkered Pavement Tiles",
    "category": "瓷砖纹理",
    "file": "part-04/checkered_pavement_tiles.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/checkered_pavement_tiles",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "5d5215863853738771dc1ef2f96aa5bfb6740e2f98688c53d82f66f20d672588",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brown Leather",
    "category": "皮革纹理",
    "file": "part-04/brown_leather.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brown_leather",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "7e9e1d6566d1fd91d4ceb4966c4820361e85d53a7a828b6bab3b2a093a876cd1",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt 01",
    "category": "柏油纹理",
    "file": "part-04/asphalt_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_01",
    "author": {
      "Dario Barresi": "Processing ",
      "Charlotte Baglioni": "Photography"
    },
    "sha256": "99b6f6bdfbd09279f3f550ac9593336df541aa2319537566eeb3e737d8512010",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Grass Rock",
    "category": "岩石纹理",
    "file": "part-04/aerial_grass_rock.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_grass_rock",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "57b8041bfe0d0f01430e4dbaad45e7ddddf0a9fc97317f90dbc51f7b0d9e1b5d",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Concrete Tiles 02",
    "category": "瓷砖纹理",
    "file": "part-04/concrete_tiles_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/concrete_tiles_02",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "2b0af74cd45e3e0e31ad309499929b8957eab624994e820ac39ed4c0d1022b39",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Corrugated Iron",
    "category": "金属纹理",
    "file": "part-04/corrugated_iron.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/corrugated_iron",
    "author": {
      "Jenelle van Heerden": "Processing",
      "Dimitrios Savva": "Photography"
    },
    "sha256": "7f3649dd0d056a55a910146f09b1d5298370696a90f511a255fb4c5715bb4b58",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Medieval Blocks 03",
    "category": "砖石纹理",
    "file": "part-04/medieval_blocks_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/medieval_blocks_03",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "3852b4a60e0f62d2914c895f884df8d58d8d12d788851d814859dae05b7620cf",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brick 4",
    "category": "砖石纹理",
    "file": "part-04/brick_4.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brick_4",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "8b2492a0483446093038c5620dce1fa7c9f66c4824985030b3c95dba77ac0269",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brown Mud Leaves 01",
    "category": "其他材质纹理",
    "file": "part-04/brown_mud_leaves_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brown_mud_leaves_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "c598c555f13cd5328409fd5e2a45496a26e319e52299e3959042f1449c2f1b06",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Gravelly Sand",
    "category": "沙土纹理",
    "file": "part-04/gravelly_sand.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/gravelly_sand",
    "author": {
      "Dario Barresi": "All"
    },
    "sha256": "bc1624594ce807f04eaa023f6f9df93ffefd20904570cd46ca302b954ef80eec",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Leather White",
    "category": "皮革纹理",
    "file": "part-04/leather_white.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/leather_white",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "4d916dfe89c9d2b88bf52e0c70c6a9798a5c29c8c2fcb6ba1ab7b7ded9ef3ed5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt Pit Lane",
    "category": "柏油纹理",
    "file": "part-04/asphalt_pit_lane.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_pit_lane",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "8aad5097f6de913aebc33f2b9b9271834b55c6942359955722db3196a9ce9bca",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Rocks 04",
    "category": "岩石纹理",
    "file": "part-04/aerial_rocks_04.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_rocks_04",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "5ac472016a6740bd3c62b1d719bf128e0659022fb35853f4e847737522337ffa",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Red Laterite Soil Stones",
    "category": "沙土纹理",
    "file": "part-05/red_laterite_soil_stones.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/red_laterite_soil_stones",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "949cd648409b30e2267d89066965605d22dba4ce73d601673e155046c41e1219",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt Track",
    "category": "柏油纹理",
    "file": "part-05/asphalt_track.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_track",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "05c4e79cd99160075969d37bfc6ef72be262153a410bb45510b2c23f7303894c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Blue Metal Plate",
    "category": "金属纹理",
    "file": "part-05/blue_metal_plate.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/blue_metal_plate",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "a0162bffce47d4a35613a12af22571b28c18412dc5805cbb69eac343554ef750",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brown Floor Tilles",
    "category": "瓷砖纹理",
    "file": "part-05/brown_floor_tiles.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brown_floor_tiles",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "64a5e4af8521883fb82a2e17971f785bfedcbb55bc14fa2d339bc806cbea61b6",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt 02",
    "category": "其他材质纹理",
    "file": "part-05/asphalt_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "1aa5ce99f58a625c71d48cfc3e68b65ca85ccb00f39e045c0a928608a0ea25ed",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Dirty Concrete",
    "category": "沙土纹理",
    "file": "part-05/dirty_concrete.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/dirty_concrete",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "322c588a5e883c27743c9555833ca3c4e95fbb20796a81559bb082a94569ce2c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Grey Cartago 03",
    "category": "瓷砖纹理",
    "file": "part-05/grey_cartago_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/grey_cartago_03",
    "author": {
      "Lucas Sánchez Ros": "All"
    },
    "sha256": "38847595a6f7bf4410aa25a5dbb381d1ac17b9d3475a393537918b59fca21dd3",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Rock Face 03",
    "category": "岩石纹理",
    "file": "part-05/rock_face_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/rock_face_03",
    "author": {
      "Dario Barresi": "Photography",
      "Rico Cilliers": "Processing"
    },
    "sha256": "ea48e0e47ad42c8bd312476178b1248ec66f0eb19156a26a1c222f2a40caaf2d",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Cracked Concrete Wall",
    "category": "砖石纹理",
    "file": "part-05/cracked_concrete_wall.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/cracked_concrete_wall",
    "author": {
      "Dimitrios Savva": "Photography, processing",
      "Rico Cilliers": "Guidance"
    },
    "sha256": "f910cbaff5a0fbd778a8c41947ac826f2313e70e9b4077bc39221a417fa8d5b4",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt 06",
    "category": "柏油纹理",
    "file": "part-05/asphalt_06.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_06",
    "author": {
      "Jan Martens": "All"
    },
    "sha256": "eb513e6d769aa1b43850826b6eb75a4f361b80ce7694153beacc0ea1a0399c26",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Corrugated Iron 02",
    "category": "金属纹理",
    "file": "part-05/corrugated_iron_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/corrugated_iron_02",
    "author": {
      "Jenelle van Heerden": "Processing",
      "Sergej Majboroda": "Photography"
    },
    "sha256": "7a7b43099d015c1b08ebb175da5965caeae44b86de65a727b3fffa20a7c69a93",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Fabric Leather 02",
    "category": "皮革纹理",
    "file": "part-05/fabric_leather_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/fabric_leather_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "97ba9480c7619efc9b8c08202c3e3773d1dd532dacce4dfe97f86e95339cf132",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Castle Brick 02 Red",
    "category": "砖石纹理",
    "file": "part-05/castle_brick_02_red.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/castle_brick_02_red",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "526019deb0533920273a0a2272f7735ca17bb578427515c6b972e2bbecf5726c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Fabric Leather 01",
    "category": "皮革纹理",
    "file": "part-05/fabric_leather_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/fabric_leather_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "19d8935e5f9ece35b422290b1a0333cc438fabab88990d8217ee37408bc33c64",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Grassy Cobblestone",
    "category": "沙土纹理",
    "file": "part-05/grassy_cobblestone.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/grassy_cobblestone",
    "author": {
      "Dario Barresi": "Processing ",
      "Charlotte Baglioni": "Photography"
    },
    "sha256": "9e7ba40919fd1bb4b98397b9522de0e6e537be8ea4121344772238d63fe50fcc",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Forest Ground 01",
    "category": "其他材质纹理",
    "file": "part-05/forrest_ground_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/forrest_ground_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "3dd6875cb3908e022a3c45ebbffa5e84c670ff2691fbbb6dc9ea4bff88523800",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Grey Cartago 01",
    "category": "瓷砖纹理",
    "file": "part-05/grey_cartago_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/grey_cartago_01",
    "author": {
      "Lucas Sánchez Ros": "Photography",
      "Jenelle van Heerden": "Processing"
    },
    "sha256": "850a297569e17d41bc978341767a775c8f4950c6e020ed27a0078cca956189fc",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt Floor",
    "category": "柏油纹理",
    "file": "part-05/asphalt_floor.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_floor",
    "author": {
      "eye-candy.xyz": "All"
    },
    "sha256": "3c4b3ff069a45e3af920f179ab8446a24c9c5cba32c563c235301e638e0ffb55",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Metal Plate 02",
    "category": "金属纹理",
    "file": "part-05/metal_plate_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/metal_plate_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6e80877d0e9d5973d96298c6091df7ace906b0a6760afc4f3592e4855f3f1d4c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Forest Ground 04",
    "category": "岩石纹理",
    "file": "part-05/forest_ground_04.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/forest_ground_04",
    "author": {
      "Rob Tuytel": "Photography, Processing",
      "Rico Cilliers": "Minor adjustment"
    },
    "sha256": "50a4dda30875020c64385261aa7e00e2155b592302fa6794165f58fae73cbd2c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Denim Fabric 02",
    "category": "布料纹理",
    "file": "part-05/denmin_fabric_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/denmin_fabric_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "fba56bdb36b4a68cd5b01e8afa69c59f52970508e0042d4189562a08c77021cc",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Grey Plaster",
    "category": "其他材质纹理",
    "file": "part-05/grey_plaster.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/grey_plaster",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "dcf34c5f3801cc43189f0edae3c430b602c827956e9d6ce4b89a85e53e952da9",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brick Wall 001",
    "category": "砖石纹理",
    "file": "part-06/brick_wall_001.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brick_wall_001",
    "author": {
      "Rob Tuytel": "Processing",
      "Dimitrios Savva": "Photography"
    },
    "sha256": "6a1233ec0186703de830354d89f122991e61e67fb67e0846c7eaf6c5aefea902",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Plaster Grey 04",
    "category": "其他材质纹理",
    "file": "part-06/plaster_grey_04.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/plaster_grey_04",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "e78df7d6e762fe767634278e14316564e0d4510031986239458994ec9fc5410d",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Red Bricks 04",
    "category": "砖石纹理",
    "file": "part-06/red_bricks_04.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/red_bricks_04",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "c3a51662fd3e859242d949843e88e8ca7ae50dd3bb57c4cad5b544d0a16111cd",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Coast Land Rocks 01",
    "category": "沙土纹理",
    "file": "part-06/coast_land_rocks_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/coast_land_rocks_01",
    "author": {
      "Rob Tuytel": "Photography, Processing",
      "Rico Cilliers": "Tiling, Adjustments"
    },
    "sha256": "21ba7fb3fd61e54d4256013673cff00fc837a242c52bbbe178d55c628536a07f",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Rock Boulder Dry",
    "category": "岩石纹理",
    "file": "part-06/rock_boulder_dry.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/rock_boulder_dry",
    "author": {
      "Dimitrios Savva": "Photography",
      "Rico Cilliers": "Processing"
    },
    "sha256": "20f653a42fb24f42aa40641663070d578678da49af18cc1049dbdd4ed8679f3c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Painted Metal Shutter",
    "category": "金属纹理",
    "file": "part-06/painted_metal_shutter.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/painted_metal_shutter",
    "author": {
      "Dario Barresi": "Baking",
      "Rico Cilliers": "Processing ",
      "Charlotte Baglioni": "Photography"
    },
    "sha256": "278394aabcb5a5bd560d9904358682acc5af23666b22bd1f12558789da4aa4d2",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Clean Asphalt",
    "category": "柏油纹理",
    "file": "part-06/clean_asphalt.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/clean_asphalt",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "ddf9224e9cfa3eb2998d9097e4cd34bd3630c85e0e6798e5a0a000415a684083",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Gravel Road",
    "category": "柏油纹理",
    "file": "part-06/gravel_road.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/gravel_road",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "bccbb077a825bdd0eb6f607939578a6ee549822824278fb3a828f6eed3d05d45",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Rectangular Facade Tiles",
    "category": "瓷砖纹理",
    "file": "part-06/rectangular_facade_tiles.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/rectangular_facade_tiles",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "583eafdfc03da4a74509ba545c5ea808c8bdc6e883763a804fcbe859c120afb9",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Granite Tile 03",
    "category": "瓷砖纹理",
    "file": "part-06/granite_tile_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/granite_tile_03",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "bdb28bea17413f1a05b0498b43e9f61f253bb72d753d3bf6b555cbf5f3c9b1b4",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Coast Sand 05",
    "category": "沙土纹理",
    "file": "part-06/coast_sand_05.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/coast_sand_05",
    "author": {
      "Rob Tuytel": "Photography",
      "Dario Barresi": "Processing"
    },
    "sha256": "3af6ab9fc565ece74fca08f4daf4ac903dd64e9370f1239176ec68f2f3dcdf6b",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Rock 01",
    "category": "岩石纹理",
    "file": "part-06/rock_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/rock_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "0b5f0418eb1e686190c5d33bb54c400b1f9ed58813b5e34aa5e573a5197302b5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Dirty Tiles",
    "category": "瓷砖纹理",
    "file": "part-06/dirty_tiles.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/dirty_tiles",
    "author": {
      "Matterfield": "Photography",
      "Jenelle van Heerden": "Processing"
    },
    "sha256": "33b9caead078f88174553d1ba5fdbb627464cb6ff0b56e7eaee7c01fa2464958",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Metal Grate Rusty",
    "category": "金属纹理",
    "file": "part-06/metal_grate_rusty.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/metal_grate_rusty",
    "author": {
      "Rob Tuytel": "Processing",
      "Dimitrios Savva": "Photography"
    },
    "sha256": "dc24176c7cdc8f526611fca206e852179b5fe2be157eea8a180ddd8985347df8",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Concrete Wall 003",
    "category": "其他材质纹理",
    "file": "part-06/concrete_wall_003.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/concrete_wall_003",
    "author": {
      "Dimitrios Savva": "Photography",
      "Rico Cilliers": "Processing"
    },
    "sha256": "7d1d4b9f5ed1aa3e6385ef3232e26e123a3dac5f364e44f9f34784e39bf8d6bb",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Gravel Embedded Concrete",
    "category": "其他材质纹理",
    "file": "part-06/gravel_embedded_concrete.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/gravel_embedded_concrete",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "3ea5b493379c4d30c02c04b93361d3e34f91ed04058ffb4ea915702f1cd17049",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Mud Cracked Dry 03",
    "category": "沙土纹理",
    "file": "part-06/mud_cracked_dry_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/mud_cracked_dry_03",
    "author": {
      "Dario Barresi": "Processing",
      "Dimitrios Savva": "Photography"
    },
    "sha256": "b49e3d76bbb142c30ce938327f42ffdfd465429dd694fb5c2b731de08d7f6310",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt 03",
    "category": "柏油纹理",
    "file": "part-06/asphalt_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_03",
    "author": {
      "Dario Barresi": "processing",
      "Charlotte Baglioni": "photography"
    },
    "sha256": "95ad02e2631c41cf9fdd6a37596cf75adb4fb8a8b6880567cc78ed1c41dc5681",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Brick Wall 006",
    "category": "砖石纹理",
    "file": "part-06/brick_wall_006.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/brick_wall_006",
    "author": {
      "Jan Burghardt": "All"
    },
    "sha256": "4af90c68ddaee080daaa41f3c3d974d47d7549fdf33014d756dd0d6d75622819",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Gray Rocks",
    "category": "岩石纹理",
    "file": "part-06/gray_rocks.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/gray_rocks",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "4c3b6fada26a9b564ca110ad47bca5921eceefc611d970159ce559c3c50728a0",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Container Side",
    "category": "金属纹理",
    "file": "part-06/container_side.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/container_side",
    "author": {
      "Dimitrios Savva": "All"
    },
    "sha256": "9d6a8a9a243b6111f9d13af12d90325f0f1d52e45c2e1731f2d496702f024452",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Coast Sand 02",
    "category": "沙土纹理",
    "file": "part-06/coast_sand_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/coast_sand_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6854bc49936d7b2971b579095c21342ad2c8fd1495aa3382b840335202964f53",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Factory Brick",
    "category": "砖石纹理",
    "file": "part-06/factory_brick.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/factory_brick",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "3de1dbf92a786ce7785bac87447961f496404cb4f76dc80510f6e967e6577e6a",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Corrugated Iron 03",
    "category": "金属纹理",
    "file": "part-07/corrugated_iron_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/corrugated_iron_03",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "d1378cbe96c625f79180147873c586bfc653ef5a66ea7a4a58cd5b18701f2bb4",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Denim Fabric",
    "category": "布料纹理",
    "file": "part-07/denim_fabric.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/denim_fabric",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "d6d0254e2c90768482b0be8cfdc16e18117acc92bad00d406fd4b9be24facdec",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Rocks 01",
    "category": "岩石纹理",
    "file": "part-07/aerial_rocks_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_rocks_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "0f184f4a1da57342d240086b5abfb804bb129bc649024c9546b054bb918264b7",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Rectangular Facade Tiles 02",
    "category": "瓷砖纹理",
    "file": "part-07/rectangular_facade_tiles_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/rectangular_facade_tiles_02",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "146f98ad9f724faeff81836e585ed109e5efce99325d752ed1961b764c03a27c",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Concrete Floor 01",
    "category": "其他材质纹理",
    "file": "part-07/concrete_floor_01.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/concrete_floor_01",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "db7c800f1464359b5f359fc743e82ac51b34e014fdfd53844f4af34bb1949229",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Forest Leaves 02",
    "category": "其他材质纹理",
    "file": "part-07/forest_leaves_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/forest_leaves_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "2bac85cdc76927fa7dc311037bbbc4dfa2633ea56eb0a24c9cabe163a68c9aa5",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Dirt Aerial 02",
    "category": "沙土纹理",
    "file": "part-07/dirt_aerial_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/dirt_aerial_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "6a039c20e1e702733b88c429c06994cc9403c1a049e72af70750db1ea3e3e743",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Asphalt Snow",
    "category": "柏油纹理",
    "file": "part-07/asphalt_snow.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/asphalt_snow",
    "author": {
      "eye-candy.xyz": "All"
    },
    "sha256": "07ca86302150f68f3cf72735fb3d0eb5657d180cc53cfaf48aae9c36305def84",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Medieval Red Brick",
    "category": "砖石纹理",
    "file": "part-07/medieval_red_brick.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/medieval_red_brick",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "72f9d1c0479ca5872b04e2c52cfb2074fa53f0e524c1a49afa7a033fee571d1d",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Large Red Bricks",
    "category": "砖石纹理",
    "file": "part-07/large_red_bricks.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/large_red_bricks",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "f9f1f0f2c0302c13741b92e2382c5c0e34beee32628fb1d6853a27a3071e05a9",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Ganges River Pebbles",
    "category": "岩石纹理",
    "file": "part-07/ganges_river_pebbles.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/ganges_river_pebbles",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "8a52d8712e8fc184eee1f8fd4598f051c9d82dfa00371b1b88e1d2c7518faa56",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Dirty Carpet",
    "category": "布料纹理",
    "file": "part-07/dirty_carpet.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/dirty_carpet",
    "author": {
      "Rohit Seervi": "All"
    },
    "sha256": "b0ef2b248cb7dfa1d33f1b2215fb3b83e815527d4091a2c3a423bdcd63bef60a",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Cobblestone Embedded Asphalt",
    "category": "柏油纹理",
    "file": "part-07/cobblestone_embedded_asphalt.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/cobblestone_embedded_asphalt",
    "author": {
      "Amal Kumar": "All"
    },
    "sha256": "49d9a469c471798747e3d62efd65a806002c64bd91a196e2f04d9d1cb4c33212",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Gravel Concrete 03",
    "category": "其他材质纹理",
    "file": "part-07/gravel_concrete_03.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/gravel_concrete_03",
    "author": {
      "Charlotte Baglioni": "All"
    },
    "sha256": "ba89e69d3eaf9e4568d5ae62171f042d1ca20f8b500e1d7ff293a99fb4e7cb8d",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Sand",
    "category": "沙土纹理",
    "file": "part-07/aerial_sand.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_sand",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "d5195c44aec087d2a30d3ca3a3fa3458a1898986e0572e9a8043f8245598557a",
    "source_format": "Poly Haven 1K diffuse JPEG"
  },
  {
    "title": "Aerial Beach 02",
    "category": "沙土纹理",
    "file": "part-07/aerial_beach_02.jpg",
    "width": 1024,
    "height": 1024,
    "license": "CC0 1.0",
    "source": "https://polyhaven.com/a/aerial_beach_02",
    "author": {
      "Rob Tuytel": "All"
    },
    "sha256": "51a1a52942598a31156d671dc931d8c700d8a1fdfb462ee186699e8ee4ed0c15",
    "source_format": "Poly Haven 1K diffuse JPEG"
  }
];
