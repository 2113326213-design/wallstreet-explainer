# 科技类 3D 模型与环境光

此目录收录 Poly Haven 的两个 3D 模型和两张 HDRI 环境光，均为 1K 版本。它们是用于三维软件的场景素材，不是现成的视频。两个模型适合解释计算机和电子技术，但均为通用示意，不能冒充真实公司的产品。

| 素材 | 内容和格式 | 原作者 | 来源 |
|---|---|---|---|
| Classic Laptop | 复古便携电脑，glTF 模型、几何文件及三张 1K 贴图 | Arrangemonk | https://polyhaven.com/a/classic_laptop |
| Circuit Board | 复古电路板，glTF 模型、几何文件及三张 1K 贴图 | Benny Weimer | https://polyhaven.com/a/circuit_board |
| Studio Small 06 | 摄影棚环境光，1K Radiance HDR | Greg Zaal | https://polyhaven.com/a/studio_small_06 |
| Small Empty Room 3 | 办公室环境光，1K Radiance HDR | Sergej Majboroda | https://polyhaven.com/a/small_empty_room_3 |

## 使用

在 Blender 中使用 `文件 → 导入 → glTF 2.0`，选择相应文件夹里的 `.gltf` 文件。请保持 `.gltf`、`.bin` 和 `textures/` 贴图目录的相对位置，否则模型可能失去纹理。HDRI 可在世界环境着色器中通过环境纹理载入，用作三维场景照明和反射。它们为低分辨率版本，适合先搭建场景；近景特写可能需要到原站下载更高分辨率版本。

## 授权与校验

上述素材均来自 Poly Haven。该站[素材许可](https://polyhaven.com/license)说明其模型、纹理及 HDRI 以 CC0 发布，可以商业使用和重新分发。素材作者与原始网页列于上表；原始文件地址、字节数和 MD5 在 `manifest.json`。下载时按照 Poly Haven 的 API 返回值核对文件长度和 MD5。Poly Haven 的网页说明、网站标识及预览效果图不包含在此许可说明里；本包没有收录这些网页内容。
