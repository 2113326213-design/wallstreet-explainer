/* 修改以下内容来替换默认数据；示例数字仅用于演示。 */
window.CHART_DATA={
  "type":"bar", "title":"收入结构对比", "subtitle":"把占位数字替换成你已经核实的数据", "unit":" 亿", "source":"示例数据 · 请替换为真实来源与日期",
  "items":[{"label":"业务 A","value":40},{"label":"业务 B","value":68},{"label":"业务 C","value":91},{"label":"业务 D","value":54}]
};
