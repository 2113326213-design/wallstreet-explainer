# 人声笑声与夸张反应

此目录包含 75 条，具体名称、作者、来源页面、文件、时长、校验和与许可证均逐项写在 `manifest.json`。它们是供试听的替代音效，并非剪映原版，也不代表中国短视频热榜。

- **10 条 CC0**：来自 OpenGameArt 各录音作者，包含群体笑声、夸张怪笑和惊吓尖叫。OGG 是来源的原始格式，个别文件包含多个表演，但每个文件只算一条。CC0 许可说明：https://creativecommons.org/publicdomain/zero/1.0/
- **10 条 CC BY 3.0**：来自 [bart 的 24 cute fighting game voice recordings](https://opengameart.org/content/24-cute-fighting-game-voice-recordings)，选取高音调真人表演的惊呼或语气声。可免费商用、再分发，但**必须署名**：请注明作者 bart、来源 https://opengameart.org/content/24-cute-fighting-game-voice-recordings、许可 https://creativecommons.org/licenses/by/3.0/ ，并注明有无修改。原页面还要求署名包括 `http://opengameart.org` 的链接。这些是英文语气声，不是中文梗。

试听后选择适合的素材。尖叫类可能较响，请注意音量；部分 OGG/WAV 的时长和响度不同。版权声明并不代表其中每个声音都能符合你的审美或具体发布平台限制。

另包含 **55 条 CC BY 3.0 搞怪角色声音**，来自 [Little Robot Sound Factory — Voices Sound Effects Library](https://opengameart.org/content/voices-sound-effects-library) 中的 `Alien_Funny` 文件。这些是作者提供的不同 MP3 文件，适合作为卡通角色反应；不是中国短视频原声，也不是已核实的真人笑声。使用和分发时需署名 `Little Robot Sound Factory`，注明素材来源及[CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)许可和是否修改，并按作者要求尽可能提供其网站 https://www.littlerobotsoundfactory.com/ 。为了避免下载无关的 100MB 包，按源 ZIP 的完整文件条目从官方源提取了此系列，未变速或拆分。
