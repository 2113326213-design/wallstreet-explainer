# 逗比与综艺反应音效 · 试听审核包

这份独立试听包包含 **200 条音频文件**：用于乌鸦、冷场、笑声、惊呼、卡通角色、滑稽拟音等场景的可免费商用替代声音。它们不是剪映原版，不是中国热榜，也不是 200 种完全不同的声音机制；其中有相似风格的不同录音和角色声。用户需要根据实际内容和审美试听。

## 数量和来源

- `animals/`：26 条乌鸦、蟋蟀、动物模仿和玩具声。包括 3 条乌鸦类（含人声模仿）、1 条蟋蟀冷场。逐项来源见 `animals/manifest.json` 和说明。9 条来自同一幼崽合集，其原始作者与具体文件的对应关系是基于动物类别的推断，已标记为不确定。
- `voices/`：75 条笑声、惊吓及卡通角色声音，其中 10 条 CC0、65 条 CC BY 3.0。65 条包括 10 个 bart 的卡通声音和 55 个 Little Robot Sound Factory 的角色声；后者是搞怪外星角色的不同音频文件，并不代表 55 条真人笑声，也可能不适合每种剪辑。某些单个文件包含多段表演，本目录仍按文件数计数。
- `cartoon/`：79 条卡通撞击、弹簧、金属晃动、趣味拟音、怪趣声及游戏角色叫声；其中 13 条为 SFXMint AI 生成或程序合成，其余有实录、处理过的声音及合成音效，详见 `cartoon/manifest.json`。
- `reused/`：20 条从此前的 456 条试听包中挑出的原创合成弹跳和趣味反应声，明确是复用，不是新发现。

## 试听

双击 `试听逗比音效.html`，用浏览器播放；可以搜索或按分类、许可筛选，点击“下载”保存单条声音。把整个文件夹一起保留，试听页面可以离线使用。源文件为 WAV、OGG、MP3 混合格式；转为 WAV 不代表原始音质提高。部分录音有背景噪声或较大音量，建议先试听、调音量。程序已检查解码、非静音、文件哈希和清单路径，但没有逐条人工听审。

## 商业使用和署名

- **135 条 CC0**：各来源标记 CC0，允许免费商用与再分发。请保留来源说明，避免把音效误称为剪映原版或独家授权。
- **65 条 CC BY 3.0**：允许免费商用与再分发，但需要按许可署名、注明来源和许可证、标明是否修改。`voices/README.md` 与 `voices/manifest.json` 分别列出作者及逐项来源。具体作品如果使用这些声音，须在作品、简介或随附说明中提供适当署名。

可参考的署名文字（只保留你实际使用的部分，并按修改情况调整）：

> 声音素材：bart，[24 cute fighting game voice recordings](https://opengameart.org/content/24-cute-fighting-game-voice-recordings)，[CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)，来源平台 https://opengameart.org/；修改情况：[填写]。
>
> 声音素材：Little Robot Sound Factory，[Voices Sound Effects Library](https://opengameart.org/content/voices-sound-effects-library)，[CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)；作者网站 https://www.littlerobotsoundfactory.com/；修改情况：[填写]。

请以实际素材页面和许可证为准。素材授权不等于对它所描绘内容或其他权利的保证。二次分发时应保留本说明和各目录的许可、出处及作者信息。
