# GL Transitions 免费商用转场

打开 `index.html` 可离线预览转场；按英文名称或描述搜索，拖动进度可查看转场的每一帧。预览中的文字与渐变是示意画面。数据包含每个效果的原始作者、许可证、源代码和默认参数；`transitions.json` / `transitions-data.js` 逐项保留了这些信息及源代码中的版权声明。项目总许可证见 `LICENSE.txt`；大多数转场标注 MIT，两项分别为 BSD 2-Clause 和 BSD 3-Clause，请保留对应源码内的版权和条款。来源：https://github.com/gl-transitions/gl-transitions

## 精确按帧使用

在本地页面载入 `transitions-data.js` 和 `vfx-engine.js`，将两个图像、canvas 或已解码的视频帧提供给 `engine.setImages(from, to)`。选取效果 `const fx=VFX_TRANSITIONS.find(x => x.name==='CrossZoom')`；然后在每一帧使用 `engine.draw(fx, progress)`，其中 progress 为 0 到 1。`engine.asDataURL(fx, progress)` 返回可插入 HTML 的 PNG data URL；请测试实际使用场景的性能。进度应从镜头时间计算，例如 `Math.max(0, Math.min(1,(t-t0)/duration))`。不要依赖预览页的播放计时器生成成片。

`DisplacementMap` 和 `LumaWipe` 额外需要提供贴图，使用 `engine.draw(fx, progress, {}, {displacementMap: image})` 或 `{luma: image}`；预览使用程序生成的灰度示意贴图。不是所有转场都适合严肃财经视频，使用时请根据内容克制选择，避免影响阅读。

渲染器对页面每一帧调用 `window.seek(t)`。如 `film.js` 通过重写 `stage.innerHTML` 构造镜头，应将 `engine.asDataURL` 嵌入 `<img src="...">`，确保两张来源图像提前加载并解码，避免每次 seek 用动画时钟取值。该适配器未改变现有 Skill 或自动安装进其他剪辑软件。
