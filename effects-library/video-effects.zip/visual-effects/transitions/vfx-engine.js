/* WebGL adapter for gl-transitions. Per-effect author/license comments remain in transitions-data.js. */
(function (global) {
  'use strict';
  const vert = 'attribute vec2 position; varying vec2 uv; void main(){uv=position*.5+.5;gl_Position=vec4(position,0.,1.);}';
  class TransitionEngine {
    constructor(canvas) {
      this.canvas=canvas; this.gl=canvas.getContext('webgl',{alpha:true,preserveDrawingBuffer:true,antialias:false});
      if(!this.gl) throw Error('此设备未启用 WebGL，无法预览');
      const g=this.gl; this.buf=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,this.buf);g.bufferData(g.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),g.STATIC_DRAW);
      this.sources=[null,null];this.cache=new Map();this.extra=null;
    }
    texture(source) {
      const g=this.gl,t=g.createTexture();g.bindTexture(g.TEXTURE_2D,t);g.pixelStorei(g.UNPACK_FLIP_Y_WEBGL,true);
      g.texParameteri(g.TEXTURE_2D,g.TEXTURE_WRAP_S,g.CLAMP_TO_EDGE);g.texParameteri(g.TEXTURE_2D,g.TEXTURE_WRAP_T,g.CLAMP_TO_EDGE);
      g.texParameteri(g.TEXTURE_2D,g.TEXTURE_MIN_FILTER,g.LINEAR);g.texParameteri(g.TEXTURE_2D,g.TEXTURE_MAG_FILTER,g.LINEAR);
      g.texImage2D(g.TEXTURE_2D,0,g.RGBA,g.RGBA,g.UNSIGNED_BYTE,source);return t;
    }
    setImages(from,to) { const g=this.gl;for(const t of this.sources)if(t)g.deleteTexture(t);this.sources=[this.texture(from),this.texture(to)]; }
    build(effect) {
      if(this.cache.has(effect.name))return this.cache.get(effect.name);
      const g=this.gl;
      const frag='precision highp float; varying vec2 uv; uniform float progress; uniform float ratio; uniform sampler2D vfxFrom; uniform sampler2D vfxTo; vec4 getFromColor(vec2 p){return texture2D(vfxFrom,p);} vec4 getToColor(vec2 p){return texture2D(vfxTo,p);}\n'+effect.glsl+'\nvoid main(){gl_FragColor=transition(uv);}';
      function shader(kind,src){const s=g.createShader(kind);g.shaderSource(s,src);g.compileShader(s);if(!g.getShaderParameter(s,g.COMPILE_STATUS)){const e=g.getShaderInfoLog(s);g.deleteShader(s);throw Error(e)}return s;}
      const vs=shader(g.VERTEX_SHADER,vert),fs=shader(g.FRAGMENT_SHADER,frag),program=g.createProgram();g.attachShader(program,vs);g.attachShader(program,fs);g.linkProgram(program);g.deleteShader(vs);g.deleteShader(fs);
      if(!g.getProgramParameter(program,g.LINK_STATUS)){const msg=g.getProgramInfoLog(program);g.deleteProgram(program);throw Error(msg)}
      this.cache.set(effect.name,program);return program;
    }
    draw(effect,progress,params={},textureMap={}) {
      const g=this.gl;if(!this.sources.every(Boolean))throw Error('请先提供两张画面'); const p=this.build(effect);g.useProgram(p);g.viewport(0,0,this.canvas.width,this.canvas.height);
      g.bindBuffer(g.ARRAY_BUFFER,this.buf);let pos=g.getAttribLocation(p,'position');g.enableVertexAttribArray(pos);g.vertexAttribPointer(pos,2,g.FLOAT,false,0,0);
      const scalar=(n,v)=>{const loc=g.getUniformLocation(p,n);if(loc!==null)g.uniform1f(loc,v)};
      scalar('progress',Math.max(0,Math.min(1,progress)));scalar('ratio',this.canvas.width/this.canvas.height);
      function bindTexture(unit,t,name){let loc=g.getUniformLocation(p,name); if(loc===null)return;g.activeTexture(g.TEXTURE0+unit);g.bindTexture(g.TEXTURE_2D,t);g.uniform1i(loc,unit)}
      bindTexture(0,this.sources[0],'vfxFrom');bindTexture(1,this.sources[1],'vfxTo');
      for(const [name,type] of Object.entries(effect.paramsTypes||{})) {
        const loc=g.getUniformLocation(p,name),v=params[name]??(effect.defaultParams||{})[name];if(loc===null||v===undefined||v===null)continue;
        if(type==='float')g.uniform1f(loc,v);else if(type==='int'||type==='bool')g.uniform1i(loc,Number(v));else if(type==='vec2')g.uniform2fv(loc,v);else if(type==='vec3')g.uniform3fv(loc,v);else if(type==='vec4')g.uniform4fv(loc,v);else if(type==='ivec2')g.uniform2iv(loc,v);
      }
      const owned=[];(effect.textures||[]).forEach((name,i)=>{const source=textureMap[name];if(!source)throw Error('该效果需要额外贴图：'+name);let t=this.texture(source);owned.push(t);bindTexture(i+2,t,name)});
      g.drawArrays(g.TRIANGLE_STRIP,0,4);g.finish();owned.forEach(t=>g.deleteTexture(t));return this.canvas;
    }
    asDataURL(effect,progress,params={},textureMap={}) {return this.draw(effect,progress,params,textureMap).toDataURL('image/png');}
  }
  global.VFXTransitionEngine=TransitionEngine;
})(window);
