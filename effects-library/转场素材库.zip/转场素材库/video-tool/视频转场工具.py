#!/usr/bin/env python3
"""Combine two video clips using FFmpeg xfade. No external Python packages."""
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

EFFECTS = ('fade wipeleft wiperight wipeup wipedown slideleft slideright slideup slidedown '
           'circlecrop rectcrop distance fadeblack fadewhite radial smoothleft smoothright smoothup smoothdown '
           'circleopen circleclose vertopen vertclose horzopen horzclose dissolve pixelize diagtl diagtr diagbl diagbr '
           'hlslice hrslice vuslice vdslice hblur fadegrays wipetl wipetr wipebl wipebr squeezeh squeezev zoomin '
           'fadefast fadeslow hlwind hrwind vuwind vdwind coverleft coverright coverup coverdown '
           'revealleft revealright revealup revealdown').split()

def duration(ffmpeg, path):
    # ffprobe is usually installed next to ffmpeg; fallback supports standalone FFmpeg.
    candidate = Path(ffmpeg).with_name('ffprobe')
    probe = str(candidate) if candidate.is_file() else shutil.which('ffprobe')
    if probe:
        cmd = [probe, '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', str(path)]
        try:
            value = float(subprocess.run(cmd, check=True, capture_output=True, text=True).stdout.strip())
            if value > 0:
                return value
        except (OSError, ValueError, subprocess.CalledProcessError):
            pass
    result = subprocess.run([ffmpeg, '-hide_banner', '-i', str(path)], capture_output=True, text=True)
    match = re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)', result.stderr)
    if match:
        hours, minutes, seconds = map(float, match.groups())
        return hours * 3600 + minutes * 60 + seconds
    raise ValueError('无法读取视频时长，请检查文件是否可播放。')

def resolve_ffmpeg(value=None):
    found = value or shutil.which('ffmpeg')
    if not found:
        raise ValueError('找不到 FFmpeg。请先安装 FFmpeg，或在命令行使用 --ffmpeg 指定程序路径。')
    return found

def render(a, b, output, effect='fade', seconds=1.0, ffmpeg=None):
    ffmpeg = resolve_ffmpeg(ffmpeg)
    a, b, output = Path(a).expanduser().resolve(), Path(b).expanduser().resolve(), Path(output).expanduser().resolve()
    if not a.is_file() or not b.is_file():
        raise ValueError('请先选择两段有效的视频文件。')
    if output in (a, b):
        raise ValueError('输出路径不能与输入视频相同。')
    if output.suffix.lower() != '.mp4':
        raise ValueError('输出文件必须以 .mp4 结尾。')
    if not output.parent.is_dir():
        raise ValueError('输出文件夹不存在。')
    if effect not in EFFECTS:
        raise ValueError('未知转场名称，请使用 --list 查看可选名称。')
    if not (0.1 <= seconds <= 10):
        raise ValueError('转场时长必须在 0.1 至 10 秒之间。')
    d1, d2 = duration(ffmpeg, a), duration(ffmpeg, b)
    if seconds >= min(d1, d2):
        raise ValueError(f'转场时长必须短于两段视频各自的时长（{d1:.2f} 秒、{d2:.2f} 秒）。')
    # Normalize video formats and time bases so xfade accepts mixed inputs.
    norm = 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,format=yuv420p,settb=AVTB,setpts=PTS-STARTPTS,fps=30'
    graph = f'[0:v:0]{norm}[a];[1:v:0]{norm}[b];[a][b]xfade=transition={effect}:duration={seconds:.6f}:offset={d1-seconds:.6f}[v]'
    fd, temporary = tempfile.mkstemp(prefix='.transition-', suffix='.mp4', dir=output.parent)
    os.close(fd)
    try:
        cmd = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-y', '-i', str(a), '-i', str(b),
               '-filter_complex', graph, '-map', '[v]', '-an', '-c:v', 'libx264', '-preset', 'medium', '-crf', '20',
               '-pix_fmt', 'yuv420p', '-movflags', '+faststart', temporary]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError('转场生成失败。请确认 FFmpeg 版本支持该效果。\n' + result.stderr[-3000:])
        os.replace(temporary, output)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return output

def gui():
    try:
        import tkinter as tk
        from tkinter import ttk, filedialog, messagebox
    except ImportError:
        raise RuntimeError('无法启动窗口：当前 Python 未安装 tkinter。请参阅说明，使用命令行模式。')
    root = tk.Tk()
    root.title('视频转场工具')
    root.resizable(True, False)
    wrapper = ttk.Frame(root, padding=20)
    wrapper.grid(sticky='nsew')
    wrapper.columnconfigure(1, weight=1)
    vars = {x: tk.StringVar() for x in ('a', 'b', 'output')}
    def choose(name, save=False):
        opts = {'filetypes': [('视频文件', '*.mp4 *.mov *.m4v *.mkv *.webm'), ('所有文件', '*')]}
        if save:
            path = filedialog.asksaveasfilename(defaultextension='.mp4', filetypes=[('MP4 视频','*.mp4')])
        else:
            path = filedialog.askopenfilename(**opts)
        if path:
            vars[name].set(path)
    for row, (key, label) in enumerate([('a','第一段视频'),('b','第二段视频'),('output','保存到')]):
        ttk.Label(wrapper,text=label).grid(row=row,column=0,sticky='w',pady=5)
        ttk.Entry(wrapper,textvariable=vars[key],width=50).grid(row=row,column=1,sticky='ew',padx=8)
        ttk.Button(wrapper,text='选择',command=lambda k=key:choose(k,k=='output')).grid(row=row,column=2)
    effect=tk.StringVar(value='fade'); seconds=tk.StringVar(value='1')
    ttk.Label(wrapper,text='转场样式').grid(row=3,column=0,sticky='w',pady=5)
    ttk.Combobox(wrapper,textvariable=effect,values=EFFECTS,state='readonly').grid(row=3,column=1,sticky='ew',padx=8)
    ttk.Label(wrapper,text='时长（秒）').grid(row=4,column=0,sticky='w',pady=5)
    ttk.Entry(wrapper,textvariable=seconds).grid(row=4,column=1,sticky='ew',padx=8)
    ttk.Label(wrapper,text='输出为 720p、30 帧/秒的无声 MP4；需要的音频请在剪辑软件中添加。',wraplength=500).grid(row=5,column=0,columnspan=3,sticky='w',pady=8)
    status=tk.StringVar(value='选择两段视频后，点击生成。')
    ttk.Label(wrapper,textvariable=status,wraplength=500).grid(row=6,column=0,columnspan=3,sticky='w')
    def start():
        import threading
        try:
            values = vars['a'].get(), vars['b'].get(), vars['output'].get(), effect.get(), float(seconds.get())
            if not all(values[:3]):
                raise ValueError('请先选择两段视频和输出路径。')
            if Path(values[2]).expanduser().exists() and not messagebox.askyesno('覆盖文件','输出文件已存在，是否覆盖？'):
                return
            resolve_ffmpeg()
        except (ValueError, OSError) as exc:
            messagebox.showerror('请检查输入',str(exc)); return
        button.configure(state='disabled'); status.set('正在生成，请稍候……')
        def run():
            try:
                out=render(*values)
                root.after(0,lambda:(status.set('已生成：'+str(out)), button.configure(state='normal'),messagebox.showinfo('完成','已生成：\n'+str(out))))
            except Exception as exc:
                msg=str(exc)
                root.after(0,lambda:(status.set('生成失败，请检查输入。'),button.configure(state='normal'),messagebox.showerror('生成失败',msg)))
        threading.Thread(target=run,daemon=True).start()
    button=ttk.Button(wrapper,text='生成 MP4',command=start)
    button.grid(row=7,column=0,columnspan=3,pady=(12,0))
    root.mainloop()

def main():
    p=argparse.ArgumentParser(description='给两段视频添加转场；输出为无声 720p MP4。')
    p.add_argument('first',nargs='?'); p.add_argument('second',nargs='?'); p.add_argument('output',nargs='?')
    p.add_argument('--effect',choices=EFFECTS,default='fade'); p.add_argument('--duration',type=float,default=1.0)
    p.add_argument('--ffmpeg',help='ffmpeg 程序路径'); p.add_argument('--list',action='store_true',help='列出全部转场名称')
    args=p.parse_args()
    if args.list:
        print('\n'.join(EFFECTS));return
    if not any((args.first,args.second,args.output)):
        gui();return
    if not all((args.first,args.second,args.output)):
        p.error('命令行模式需提供第一段、第二段及输出文件')
    if Path(args.output).expanduser().exists():
        p.error('输出文件已存在；请更换输出路径，或手动删除现有文件。')
    print('已生成：',render(args.first,args.second,args.output,args.effect,args.duration,args.ffmpeg))

if __name__ == '__main__':
    try:
        main()
    except (ValueError,RuntimeError,OSError) as exc:
        print('错误：',exc,file=sys.stderr);sys.exit(1)
